STUDENT ASSIGNMENT PORTAL

WHAT THIS PROJECT DOES
1. Student page: student enters full name and uploads an assignment image.
2. Submission is saved in Firebase Storage + Firestore.
3. Teacher dashboard shows every submission.
4. Teacher can open the image and give a score from 0–100 plus a comment.
5. Dashboard calculates total submissions, number scored, and average score.
6. Export button downloads all names and scores to an Excel .xlsx file.
7. Design uses purple and white.

SETUP
A. Create a Firebase project at https://console.firebase.google.com/
B. Add a Web App and copy its Firebase configuration.
C. Open firebase-config.js and replace every PASTE_YOUR_... value.
D. In Firebase, enable:
   - Firestore Database
   - Storage
E. For a first classroom test, you can use these development rules, but replace them with secure rules before real use:

Firestore rules (development only):
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /submissions/{document} {
      allow read, write: if true;
    }
  }
}

Storage rules (development only):
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /assignments/{allPaths=**} {
      allow read, write: if true;
    }
  }
}

IMPORTANT: These rules are intentionally open for testing. Do not use them for a public production website.

RUN
Because the project uses JavaScript modules, open it through a local web server rather than double-clicking the HTML file.
In VS Code, use a local server extension such as Live Server, then open index.html.

PAGES
index.html = Student submission page
teacher.html = Teacher dashboard
firebase-config.js = Firebase settings
student.js = Student upload/submit logic
teacher.js = Scoring + Excel export
style.css = Purple/white design

EXCEL
The teacher dashboard creates student_assignment_scores.xlsx with:
Student Name, Assignment File, Submission Date, Score (%), Teacher Comment, Assignment Image URL.

SECURITY NOTE
For a real school deployment, add Firebase Authentication so only the teacher can access teacher.html, and require signed-in users for Firestore/Storage rules.
