import { db, storage } from "./firebase.js";
import { collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-storage.js";

const form = document.getElementById("submissionForm");
const fileInput = document.getElementById("assignment");
const fileName = document.getElementById("fileName");
const message = document.getElementById("message");
const submitBtn = document.getElementById("submitBtn");

fileInput.addEventListener("change", () => {
  fileName.textContent = fileInput.files[0]?.name || "";
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("studentName").value.trim();
  const file = fileInput.files[0];

  if (!name || !file) return;
  if (!file.type.startsWith("image/")) return show("Please select an image file.", true);
  if (file.size > 5 * 1024 * 1024) return show("Image must be 5 MB or smaller.", true);

  submitBtn.disabled = true;
  submitBtn.textContent = "Submitting...";
  show("");

  try {
    const safeName = name.replace(/[^a-z0-9]/gi, "_").toLowerCase();
    const fileRef = ref(storage, `assignments/${Date.now()}_${safeName}_${file.name}`);
    await uploadBytes(fileRef, file);
    const imageUrl = await getDownloadURL(fileRef);

    await addDoc(collection(db, "submissions"), {
      studentName: name,
      assignmentUrl: imageUrl,
      fileName: file.name,
      score: null,
      comment: "",
      submittedAt: serverTimestamp()
    });

    form.reset();
    fileName.textContent = "";
    show("Assignment submitted successfully.");
  } catch (error) {
    console.error(error);
    show("Submission failed. Check your Firebase setup and internet connection.", true);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Submit Assignment";
  }
});

function show(text, error=false) {
  message.textContent = text;
  message.style.color = error ? "#b91c1c" : "#15803d";
}
