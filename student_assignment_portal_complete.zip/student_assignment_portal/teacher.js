import { db } from "./firebase.js";
import { collection, getDocs, query, orderBy, doc, updateDoc } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

let submissions = [];
let selectedId = null;

const table = document.getElementById("submissionTable");
const empty = document.getElementById("emptyState");
const search = document.getElementById("searchInput");
const modal = document.getElementById("scoreModal");

async function loadSubmissions() {
  try {
    const q = query(collection(db, "submissions"), orderBy("submittedAt", "desc"));
    const snap = await getDocs(q);
    submissions = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    render();
  } catch (error) {
    console.error(error);
    empty.textContent = "Could not load submissions. Check Firebase configuration/rules.";
    empty.style.display = "block";
  }
}

function render() {
  const term = search.value.toLowerCase();
  const filtered = submissions.filter(s => (s.studentName || "").toLowerCase().includes(term));
  table.innerHTML = "";

  filtered.forEach(s => {
    const tr = document.createElement("tr");
    const date = s.submittedAt?.toDate ? s.submittedAt.toDate().toLocaleString() : "—";
    const scored = typeof s.score === "number";
    tr.innerHTML = `
      <td><strong>${escapeHtml(s.studentName || "")}</strong></td>
      <td><a href="${s.assignmentUrl}" target="_blank" rel="noopener">View image</a></td>
      <td>${date}</td>
      <td>${scored ? `${s.score}%` : "—"}</td>
      <td><span class="status ${scored ? "scored" : "pending"}">${scored ? "Scored" : "Pending"}</span></td>
      <td><button class="action-btn" data-id="${s.id}">${scored ? "Edit Score" : "Score"}</button></td>`;
    table.appendChild(tr);
  });

  table.querySelectorAll(".action-btn").forEach(btn => {
    btn.addEventListener("click", () => openScore(btn.dataset.id));
  });

  empty.style.display = filtered.length ? "none" : "block";
  document.getElementById("totalCount").textContent = submissions.length;
  const scored = submissions.filter(s => typeof s.score === "number");
  document.getElementById("scoredCount").textContent = scored.length;
  const avg = scored.length ? scored.reduce((a,s)=>a+s.score,0)/scored.length : 0;
  document.getElementById("averageScore").textContent = `${avg.toFixed(1)}%`;
}

function openScore(id) {
  const s = submissions.find(x => x.id === id);
  if (!s) return;
  selectedId = id;
  document.getElementById("modalStudent").textContent = s.studentName;
  document.getElementById("assignmentPreview").src = s.assignmentUrl;
  document.getElementById("scoreInput").value = typeof s.score === "number" ? s.score : "";
  document.getElementById("commentInput").value = s.comment || "";
  document.getElementById("scoreMessage").textContent = "";
  modal.classList.remove("hidden");
}

document.getElementById("saveScoreBtn").addEventListener("click", async () => {
  const score = Number(document.getElementById("scoreInput").value);
  const comment = document.getElementById("commentInput").value.trim();
  const msg = document.getElementById("scoreMessage");

  if (!Number.isFinite(score) || score < 0 || score > 100) {
    msg.textContent = "Enter a score from 0 to 100.";
    msg.style.color = "#b91c1c";
    return;
  }

  try {
    await updateDoc(doc(db, "submissions", selectedId), { score, comment });
    modal.classList.add("hidden");
    await loadSubmissions();
  } catch (error) {
    console.error(error);
    msg.textContent = "Could not save score.";
    msg.style.color = "#b91c1c";
  }
});

document.getElementById("closeModal").addEventListener("click", () => modal.classList.add("hidden"));
document.getElementById("refreshBtn").addEventListener("click", loadSubmissions);
search.addEventListener("input", render);

document.getElementById("exportBtn").addEventListener("click", () => {
  if (!submissions.length) return alert("There are no submissions to export.");
  const rows = submissions.map(s => ({
    "Student Name": s.studentName || "",
    "Assignment File": s.fileName || "",
    "Submission Date": s.submittedAt?.toDate ? s.submittedAt.toDate().toLocaleString() : "",
    "Score (%)": typeof s.score === "number" ? s.score : "",
    "Teacher Comment": s.comment || "",
    "Assignment Image URL": s.assignmentUrl || ""
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Scores");
  XLSX.writeFile(wb, "student_assignment_scores.xlsx");
});

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}

loadSubmissions();
